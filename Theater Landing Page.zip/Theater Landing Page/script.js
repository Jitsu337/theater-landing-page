const menuButton = document.getElementById("menuButton");
const mobileMenu = document.getElementById("mobileMenu");

menuButton.addEventListener("click", () => {
    mobileMenu.classList.toggle("hidden");
});

const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", (event) => {
    event.preventDefault();

    alert("Thank you! Your message has been received.");

    contactForm.reset();
});

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", function (event) {
        const target = document.querySelector(this.getAttribute("href"));

        if (target) {
            event.preventDefault();

            target.scrollIntoView({
                behavior: "smooth"
            });
        }
    });
});

// Scroll reveal animation
const revealElements = document.querySelectorAll(".reveal");

const revealObserver = new IntersectionObserver(
    (entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("active");
            }
        });
    },
    {
        threshold: 0.15
    }
);

revealElements.forEach((element) => {
    revealObserver.observe(element);
});

// Navbar scroll effect
const navbar = document.querySelector("header");
const navbarContainer = navbar.querySelector("nav > div");

window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
        navbarContainer.classList.add(
            "bg-black/80",
            "shadow-lg",
            "shadow-black/30"
        );

        navbarContainer.classList.remove("bg-black/30");
    } else {
        navbarContainer.classList.remove(
            "bg-black/80",
            "shadow-lg",
            "shadow-black/30"
        );

        navbarContainer.classList.add("bg-black/30");
    }
});

// Show modal
const showButtons = document.querySelectorAll(".show-button");
const showModal = document.getElementById("showModal");
const closeModal = document.getElementById("closeModal");

const modalImage = document.getElementById("modalImage");
const modalCategory = document.getElementById("modalCategory");
const modalTitle = document.getElementById("modalTitle");
const modalDate = document.getElementById("modalDate");
const modalDescription = document.getElementById("modalDescription");


const shows = {
    "last-act": {
        title: "The Last Act",
        category: "Drama",
        date: "October 24, 2026",
        description:
            "A powerful story of ambition, love and destiny. Follow one artist's final journey as the curtain begins to fall.",
        image: "./images/show-1.jpg"
    },

    "midnight-laughs": {
        title: "Midnight Laughs",
        category: "Comedy",
        date: "November 02, 2026",
        description:
            "An unforgettable night of comedy, unexpected moments and stories that will have you laughing long after the curtain closes.",
        image: "./images/show-2.jpg"
    },

    "echoes-broadway": {
        title: "Echoes of Broadway",
        category: "Musical",
        date: "November 18, 2026",
        description:
            "Music, movement and unforgettable performances come together in a spectacular celebration of the stage.",
        image: "./images/show-3.jpg"
    }
};


showButtons.forEach((button) => {

    button.addEventListener("click", () => {

        const showId = button.dataset.show;
        const show = shows[showId];

        modalImage.src = show.image;
        modalImage.alt = show.title;

        modalCategory.textContent = show.category;
        modalTitle.textContent = show.title;
        modalDate.textContent = show.date;
        modalDescription.textContent = show.description;

        showModal.classList.remove("hidden");
        showModal.classList.add("flex");

        document.body.classList.add("overflow-hidden");
    });

});


function closeShowModal() {

    showModal.classList.add("hidden");
    showModal.classList.remove("flex");

    document.body.classList.remove("overflow-hidden");

}


closeModal.addEventListener("click", closeShowModal);


// Close when clicking outside the modal
showModal.addEventListener("click", (event) => {

    if (event.target === showModal) {
        closeShowModal();
    }

});


// Close with Escape key
document.addEventListener("keydown", (event) => {

    if (event.key === "Escape" && !showModal.classList.contains("hidden")) {
        closeShowModal();
    }

});